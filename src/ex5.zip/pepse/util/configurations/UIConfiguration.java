package pepse.util.configurations;

import danogl.collisions.Layer;

public class UIConfiguration {

    public static int AVATAR_LAYER = Layer.UI;

    public static String[] AVATAR_CONFIGS =
            new String[]{"pepse\\util\\Birds\\tile000.png",
                    "pepse\\util\\Birds\\tile001.png",
                    "pepse\\util\\Birds\\tile002.png",
                    "pepse\\util\\Birds\\tile003.png",
                    "pepse\\util\\Birds\\tile004.png",
                    "pepse\\util\\Birds\\tile005.png",
                    "pepse\\util\\Birds\\tile006.png",

                    "pepse\\util\\Birds\\tile008.png"
            };
//    public static String[] AVATAR_CONFIGS = new String[]{
//            "pepse\\util\\AvatarImages\\Screenshot_20230102_084453.png",
//            "pepse\\util\\AvatarImages\\Screenshot_20230102_084525.png",
//            "pepse\\util\\AvatarImages\\Screenshot_20230102_084530.png",
//            "pepse\\util\\AvatarImages\\Screenshot_20230102_084534.png",
//            "pepse\\util\\AvatarImages\\Screenshot_20230102_084541.png",
//            "pepse\\util\\AvatarImages\\Screenshot_20230102_084547.png",
//            "pepse\\util\\AvatarImages\\Screenshot_20230102_084552.png"};




}
